package https://fhir.hl7.org.uk/STU3/StructureDefinitions/FHIR-STU3-Core-ImplementationGuide-1;

import org.hl7.fhir.r5.model.ProfilingWrapper;

public class CareConnectACVPUObservation1 {

}
